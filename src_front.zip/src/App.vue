<template>
  <router-view />
</template>

<style>
#app { max-width: 1280px; margin: 0 auto; padding: 2rem; }
</style>